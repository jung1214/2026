﻿using System;

namespace Phase04_Encapsulation
{
    public class EvenOddCalculator
    {
        private readonly int _limit;
        public int EvenSum { get; }
        public int OddSum { get; }

        public EvenOddCalculator(int limit)
        {
            if (limit < 1)
                throw new ArgumentOutOfRangeException(nameof(limit), "1 이상이어야 합니다.");

            _limit = limit;
            int even = 0;
            int odd = 0;
            for (int number = 1; number <= _limit; number++)
            {
                if (number % 2 == 0) even += number;
                else odd += number;
            }
            EvenSum = even;
            OddSum = odd;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            EvenOddCalculator calculator = new EvenOddCalculator(10);
            Console.WriteLine($"짝수 합: {calculator.EvenSum}");
            Console.WriteLine($"홀수 합: {calculator.OddSum}");
            Console.WriteLine("92514643 정서현");
            Console.ReadKey();
        }
    }
}
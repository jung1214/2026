﻿using System;

namespace Phase01_Direct
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int limit = 10;
            int evenSum = 0;
            int oddSum = 0;

            for (int number = 1; number <= limit; number++)
            {
                if (number % 2 == 0)
                    evenSum += number;
                else
                    oddSum += number;
            }

            Console.WriteLine($"짝수 합: {evenSum}");
            Console.WriteLine($"홀수 합: {oddSum}");
            Console.WriteLine("92514643 정서현");
            Console.ReadKey();
        }
    }
}
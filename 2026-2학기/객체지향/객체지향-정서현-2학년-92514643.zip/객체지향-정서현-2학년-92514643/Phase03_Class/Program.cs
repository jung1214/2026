﻿using System;

namespace Phase03_Class
{
    public class NumberCalculator
    {
        public int GetEvenSum(int limit)
        {
            int sum = 0;
            for (int number = 1; number <= limit; number++)
            {
                if (number % 2 == 0) sum += number;
            }
            return sum;
        }

        public int GetOddSum(int limit)
        {
            int sum = 0;
            for (int number = 1; number <= limit; number++)
            {
                if (number % 2 != 0) sum += number;
            }
            return sum;
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            NumberCalculator calculator = new NumberCalculator();
            int limit = 10;
            Console.WriteLine($"짝수 합: {calculator.GetEvenSum(limit)}");
            Console.WriteLine($"홀수 합: {calculator.GetOddSum(limit)}");
            Console.WriteLine("92514643 정서현");
            Console.ReadKey();
        }
    }
}
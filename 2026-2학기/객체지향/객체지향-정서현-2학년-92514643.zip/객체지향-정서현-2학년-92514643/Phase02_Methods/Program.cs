﻿using System;

namespace Phase02_Methods
{
    internal class Program
    {
        static int GetEvenSum(int limit)
        {
            int sum = 0;
            for (int number = 1; number <= limit; number++)
            {
                if (number % 2 == 0) sum += number;
            }
            return sum;
        }

        static int GetOddSum(int limit)
        {
            int sum = 0;
            for (int number = 1; number <= limit; number++)
            {
                if (number % 2 != 0) sum += number;
            }
            return sum;
        }

        static void Main(string[] args)
        {
            int limit = 10;
            Console.WriteLine($"짝수 합: {GetEvenSum(limit)}");
            Console.WriteLine($"홀수 합: {GetOddSum(limit)}");
            Console.WriteLine("92514643 정서현");
            Console.ReadKey();
        }
    }
}